---
title: Introduction to Greedy Algorithms
category: concepts
book: coding-interview-patterns
chapter: Greedy
tags: [coding-patterns, greedy, interview-prep]
created: 2026-05-05
updated: 2026-05-05
status: stub
---

Introduction to Greedy Algorithms
Intuition
Greedy algorithms are a class of algorithms that make a series of decisions, where each decision is the best immediate choice given the options available. To understand this, let’s dive into an analogy.

Imagine you're planning a road trip from city A to city E, and you want to visit cities B, C, and D along the way:

Image represents a weighted graph, a network diagram showing five nodes (A, B, C, D, E) labeled in orange, interconnected by edges representing travel times in minutes.  Node A connects to node B with three edges showing travel times of 40, 30, and 20 minutes respectively, and another edge to B with a travel time of 30 minutes. Node B connects to node C with edges of 15 and 20 minutes. Node C connects to node D with edges of 30 and 50 minutes. Node D connects to node E with edges of 30 and 35 minutes.  Node D also has an edge to node C with a travel time of 25 minutes.  All edges are unidirectional, implying travel time may vary in the opposite direction (not shown).  The numbers on the edges represent the time taken to traverse that specific connection between the nodes.
You want the fastest route for this journey, so you aim to optimize the route. One option is to check every possible route to see which one takes the least amount of time to drive through, but this approach is quite time consuming.

Instead, you decide to take the route with the shortest duration at each leg of the trip, understanding that it will result in the quickest journey:

Image represents a weighted directed graph illustrating a network of nodes (A, B, C, D, E) connected by edges representing time durations.  Each node is labeled with a capital letter in orange.  The edges are depicted as lines; thicker black lines indicate the shortest path between nodes, while thinner light-grey lines represent alternative, longer paths.  Numerical values along the edges denote the time (in minutes) it takes to traverse that connection. For example, the shortest path from A to B takes 20 minutes, while an alternative path takes 30 minutes.  The shortest path from A to E is A-B-C-D-E, with individual leg times of 20, 15, 25, and 30 minutes respectively.  Other paths exist between nodes with varying durations, such as the 35-minute connection between B and E, or the 50-minute connection between C and D. The overall diagram visualizes different routes and their associated travel times between the five locations.
This is effectively a greedy approach to the problem, where you choose the best option at each step, aiming to find the best solution overall.

How does a greedy algorithm work?
More formally, a greedy algorithm follows the greedy choice property, which states that the best overall solution to a problem (global optimum) can be arrived at by making the best possible decision at each step (local optimum).

Each decision is made based only on the current context, and ignores its impact on future steps. This process continues until the algorithm reaches a final solution.

How to tell if a problem can be solved using a greedy approach
Greedy approaches are generally used for optimization problems, similar to DP. This means we check if the problem has an optimal substructure which can be broken down and solved by smaller subproblems.

The key difference between DP and greedy approaches is their decision-making strategies. Greedy algorithms follow the greedy choice property, while DP considers all possible solutions to find the global optimum. It’s generally the case that all greedy problems can be solved using DP, but not all DP problems can be solved using a greedy approach.

Real-world Example
Huffman coding in data compression: Huffman coding is an algorithm that assigns variable-length codes to input characters based on their frequencies, with the most frequent characters getting the shortest codes. The goal is to minimize the overall size of the encoded data. The greedy approach works by always combining the two least frequent characters first (local optimum), ensuring that each step reduces the size of the overall encoding (global optimum). This method is widely used in file compression formats like ZIP, and media compression standards like JPEG.

Chapter Outline
Image represents a hierarchical diagram illustrating applications of the 'Greedy' coding pattern.  A rounded rectangle at the top, labeled 'Greedy,' acts as the root node.  From this node, two dashed lines descend, each pointing to a separate rounded rectangle representing a specific application. The left rectangle is labeled 'Reaching a Destination' and lists two sub-points: 'Jump to the End' and 'Gas Stations,' suggesting examples of problems solved using a greedy approach in this context. The right rectangle is labeled 'Resource Allocation' and lists 'Candies' as an example problem.  The overall structure shows that 'Reaching a Destination' and 'Resource Allocation' are both considered applications or examples of the broader 'Greedy' algorithmic pattern. The dashed lines indicate a hierarchical relationship, showing that the lower-level boxes are specific instances of the upper-level concept.
It’s impractical to provide a one-size-fits-all framework for solving greedy problems because each one is unique. Instead, this chapter explores a variety of unique situations in which a problem can be solved using the greedy choice property to provide a general understanding of how this property works.

> _Stub — pendiente de redacción._

[⬅ Back to KB index](../../../../README.md)
